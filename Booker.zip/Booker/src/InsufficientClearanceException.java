
public class InsufficientClearanceException extends Exception {

	public InsufficientClearanceException(String message) {
		super(message);
	}

	public InsufficientClearanceException() {
		super();
	}

}
