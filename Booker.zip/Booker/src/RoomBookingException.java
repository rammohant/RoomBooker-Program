
public class RoomBookingException extends Exception {

	public RoomBookingException(String message) {
		super(message);
	}

	public RoomBookingException() {
		super();
	}

}
